
import React from 'react';

const HomePage = () => (
  <div>
    <h1>Welcome to Beta Logic Garage</h1>
    <p>Find the best auto parts and accessories here.</p>
  </div>
);

export default HomePage;
